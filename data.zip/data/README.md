# Data sources and licences

- `connectomes/allard_serrano_2020/`: edge lists of 21 connectomes from Allard and Serrano (2020),
  "Navigable maps of structural brain networks across species", PLoS Computational Biology; licence file included.
- `connectomes/ckk_results/`: results files of Celińska-Kopczyńska and Kopczyński (2024), figshare doi:10.6084/m9.figshare.26352094.
- `connectomes/netzschleuder/`: Cook et al. (2019) C. elegans connectomes and the larval Drosophila connectome, from Netzschleuder (networks.skewed.de), CC0 catalogue.
- `football/`: match results from openfootball (github.com/openfootball), CC0.
- `trade/`: bilateral trade flows aggregated from CEPII BACI 2023 (HS22, V202601), Etalab open licence.
- `tournaments/dryad_soliveres2018/`: pairwise competition matrices, Dryad doi:10.5061/dryad.bh41r, CC0.
- `games/`: Smogon usage statistics (smogon.com/stats, checks-and-counters files, 2024) and OpenDota hero matchups (api.opendota.com, September 2026); derived dominance networks as `.npz`.
- `benchmarks/`: KONECT chess (konect.cc/networks/chess), SNAP email-Eu-core, wiki-Vote, cit-HepTh, cit-HepPh (snap.stanford.edu), political blogs (Adamic and Glance 2005, websites.umich.edu/~mejn/netdata).
- `benchmarks_undirected/`: Roget's Thesaurus (Knuth, via NetworkX example data), Planetoid CiteSeer and PubMed graphs, and the karateclub Facebook, LastFM and Twitch edge lists.
- `undirected_networks/`: the Cora ball and the pancreas kNN graph used in the undirected comparison.
