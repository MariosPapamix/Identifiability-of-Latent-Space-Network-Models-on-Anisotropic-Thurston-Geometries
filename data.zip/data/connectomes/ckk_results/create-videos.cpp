#include <stdio.h>
#include "ghutils.h"
#include <vector>
#include <string>
#include <cmath>
#include <map>
#include <set>
#include <array>

map<string, vector<string>> connectome_exp;

map<string, vector<string>> geom_exp;

void con(string co, string txt, string node) {
  connectome_exp[co] = { txt, node };
  }

void geom(string co, string txt, string node) {
  geom_exp[co] = { txt, node };
  }

map<string, int> find_column_id(csvparser& c) {
  map<string, int> column_id;
  for(int i=0; i<c.fields; i++) column_id[c[i]] = i;
  return column_id;
  }

void explain_all() {
  con("CElegans", "nervous system", "c");
  con("Cat1", "cortex", "a");
  con("Cat2", "cortex and thalamus", "a");
  con("Cat3", "cortex", "a");
  con("Drosophila1", "optic medula", "c");
  con("Drosophila2", "optic medula", "c");
  con("Macaque1", "cortex", "a");
  con("Macaque2", "cortex", "a");
  con("Macaque3", "cortex", "a");
  con("Macaque4", "cortex", "a");
  con("Mouse2", "retina", "c");
  con("Mouse3", "retina", "c");
  con("Human1", "cortex", "a");
  con("Human2", "cortex", "a");
  con("Human6", "whole brain", "a");
  con("Human7", "whole brain", "a");
  con("Human8", "whole brain", "a");
  con("Rat1", "nervous system", "a");
  con("Rat2", "nervous system", "a");
  con("Rat3", "nervous system", "a");
  con("ZebraFinch2", "basal-ganglia (Area X)", "c");

  geom("g711", "$\\mathbb{H}^2$", "bitruncated $\\{7,3\\}$");
  geom("h2m", "$\\mathbb{H}^2$\\&", "closed hyperbolic manifold");
  geom("tree", "tree", "$\\{3,\\infty\\}$");
  geom("e3b", "$\\mathbb{E}^3$", "bitruncated cubic honeycomb");
  geom("t3", "$\\mathbb{E}^3$\\&", "torus, $27 \\times 27 \\times 27$");
  geom("g435", "$\\mathbb{H}^3$", "$\\{4,3,5\\}$ hyperbolic honeycomb");
  geom("g435b2", "$\\mathbb{H}^3$*", "$\\{4,3,5\\}$ subdivided(2)");
  geom("h3m", "$\\mathbb{H}^3$\\&", "$\\{4,3,5\\}$ closed manifold");
  geom("nil", "Nil", "integer coordinates");
  geom("subnil", "Nil*", "integer coordinates, subdivided(2)");
  geom("twist", "Twist", "twisted $\\{5,4\\} \\times \\mathbb{Z}$");
  geom("h2r", "$\\mathbb{H}^2\\times\\mathbb{R}$", "bitruncated $\\{7,3\\} \\times \\mathbb{Z}$");
  geom("sol3", "Solv", "not subdivided");
  geom("subsol3", "Solv*", "subdivided");
  geom("s3", "$\\mathbb{S}^3$", "8-cell, each cell subdivided(11)");
  }

using ld = double;

map<string, int> diameters;
map<string, int> cellco;

int main() {
  explain_all();

  if(1) {
    csvparser c("csv/geostat.csv", ';');
    c.next();
    auto co = find_column_id(c);

    while(c.next()) {
      diameters[c[0]] = tonum(c[2]);
      cellco[c[0]] = tonum(c[1]);
      }
    }

  map<string, map<string, map<int, vector<ld> > > > qualities;

  set<string> whos, geoms;

  if(1) {
    csvparser c("csv/brains.csv", ';');
    c.next();
    auto co = find_column_id(c);

    while(c.next()) {
      auto who = c[co["who"]];
      auto geom = c[co["geom"]];

      int iter = tonum(c[co["iteration"]]);

      if(!connectome_exp.count(who)) continue;
      if(!geom_exp.count(geom)) continue;

      int n = tonum(c[co["n"]]);
      int m = tonum(c[co["m"]]);

      ld opt_r = tof(c[co["opt_r"]]);
      ld opt_t = tof(c[co["opt_t"]]);

      ld loglik = tof(c[co["loglik"]]);
      ld mAP = tof(c[co["mAP"]]);
      ld meanrank = tof(c[co["meanrank"]]);
      ld success = tof(c[co["success"]]);
      ld stretch = tof(c[co["stretch"]]);

      ld maxm = n * (n-1) / 2;
      ld r = maxm - m;
      ld entropy = m * log(m * 1. / maxm) + r * log(r * 1. / maxm);
      ld nll = 1 + loglik / entropy;
      ld imr = 1 / (1 + meanrank);
      ld ist = 1 / stretch;

      vector<ld> measures = {nll, mAP, imr, success, ist};
      qualities[who][geom][iter] = measures;

      whos.insert(who); geoms.insert(geom);
      }
    }

  map<string, map<string, array<int, 5>>> rankings;

  set<string> to_draw_noiter;
  set<string> to_draw;

  for(int mid=0; mid<5; mid++) {
    vector<string> names = {"csv/loglik_rank.csv", "csv/map_rank.csv", "csv/invmr_rank.csv", "csv/suc_rank.csv", "csv/invstr_rank.csv"};
    csvparser c(names[mid], ';');
    c.next();
    while(c.next()) {
      string who = c[0];
      string geom = c[1];
      rankings[who][geom][mid] = tonum(c[3]);
      }
    }

  if(0) for(int mid=0; mid<5; mid++) for(string who: whos) {
    vector<pair<ld, string>> torank;
    for(string geom: geoms) {
      ld total = 0;
      for(int iter=1; iter<30; iter++) total += qualities[who][geom][iter][mid];
      torank.emplace_back(-total, geom);
      }
    sort(torank.begin(), torank.end());
    int cid = 1, nid = 1; ld last = -999;
    for(auto t: torank) {
      if(t.first != last) cid = nid; last = t.first;
      auto geom = t.second;
      rankings[who][geom][mid] = cid;
      }
    }

  for(int mid=0; mid<5; mid++) for(string who: whos) {
    for(string geom: geoms) {
      int nid = rankings[who][geom][mid];
      if(nid <= 3) {
        ld bestval = 0;
        for(int iter=1; iter<30; iter++) bestval = max(bestval, qualities[who][geom][iter][mid]);
        for(int iter=1; iter<30; iter++) if(qualities[who][geom][iter][mid] == bestval) {

          string key_noiter = who+"/"+geom;
          if(to_draw_noiter.count(key_noiter)) continue;
          to_draw_noiter.insert(key_noiter);

          to_draw.insert(who+"/"+geom+"/"+to_string(iter));
          break;
          }
        }
      nid++;
      }
    }

  FILE *concat = fopen("videos/descs/concat.txt", "wt");
  FILE *script = fopen("videos/descs/script.sh", "wt");

  map<string, int> count_geom;
  for(int a=0; a<6; a++) fprintf(script, "echo launching process %d&\n", a);

  if(1) {
    csvparser c("csv/brains.csv", ';');
    c.next();
    auto co = find_column_id(c);

    while(c.next()) {
      auto who = c[co["who"]];
      auto geom = c[co["geom"]];

      int iter = tonum(c[co["iteration"]]);

      int n = tonum(c[co["n"]]);
      int m = tonum(c[co["m"]]);

      ld opt_r = tof(c[co["opt_r"]]);
      ld opt_t = tof(c[co["opt_t"]]);

      ld loglik = tof(c[co["loglik"]]);
      ld mAP = tof(c[co["mAP"]]);
      ld meanrank = tof(c[co["meanrank"]]);
      ld success = tof(c[co["success"]]);
      ld stretch = tof(c[co["stretch"]]);

      ld maxm = n * (n-1) / 2;
      ld r = maxm - m;
      ld entropy = m * log(m * 1. / maxm) + r * log(r * 1. / maxm);
      ld nll = 1 + loglik / entropy;
      ld imr = 1 / (1 + meanrank);
      ld ist = 1 / stretch;

      if(!connectome_exp.count(who)) continue;
      if(!geom_exp.count(geom)) continue;

      string key = who+"/"+geom+"/"+to_string(iter);
      if(!to_draw.count(key)) continue;
      // if(!to_draw.count(key) && !(who == "Macaque4" && iter == 29)) continue;
      // if(iter != 29 || who != "Macaque4") continue;

      char descfile[200];
      sprintf(descfile, "videos/descs/desc-%s-%s.txt", who.c_str(), geom.c_str());
      FILE *desc = fopen(descfile, "wt");

      fprintf(desc, "600\nvideos/full/%s-%s.mp4\n30\n", who.c_str(), geom.c_str());

      fprintf(desc, "*%s\n", who.c_str());
      fprintf(desc, ":zone=%s\n", connectome_exp[who][0].c_str());
      fprintf(desc, ":node=%s\n", connectome_exp[who][1] == "c" ? "cell" : "area");
      fprintf(desc, ":nodes=%d\n", n);
      fprintf(desc, ":edges=%d\n", m);
      fprintf(desc, "===\n", m);

      fprintf(desc, "$\\sffamily geometry %s\n", geom_exp[geom][0].c_str());
      fprintf(desc, "@\\sffamily %s\n", geom_exp[geom][1].c_str());
      fprintf(desc, ":diameter=%.3f\n", diameters[geom]/20.);
      fprintf(desc, ":cells=%d\n", cellco[geom]);
      fprintf(desc, "===\n", m);

      fprintf(desc, "*embedding\n", who.c_str());
      fprintf(desc, ":iteration=%d\n", iter);
      fprintf(desc, ":R=%.3f\n", opt_r/20);
      fprintf(desc, ":T=%.3f\n", opt_t/20);
      fprintf(desc, "===\n", m);

      fprintf(desc, "*quality\n", who.c_str());
      fprintf(desc, ":NLL=%5.3f (#%d)\n", nll, rankings[who][geom][0]);
      fprintf(desc, ":MAP=%5.3f (#%d)\n", mAP, rankings[who][geom][1]);
      fprintf(desc, ":IMR=%5.3f (#%d)\n", imr, rankings[who][geom][2]);
      fprintf(desc, ":SC=%5.3f (#%d)\n", success, rankings[who][geom][3]);
      fprintf(desc, ":IST=%5.3f (#%d)\n", ist, rankings[who][geom][4]);
      fclose(desc);

      if(geom == "g711" || geom == "tree")
      fprintf(script, "sh visualize.sh %s %s %d -csc 1 -color videos/colors-%s.csv \"movement_angle_3=dzy(90)\" rv_latex=2 -sag-autoviz -shot-fhd -shotaa 2 -lw 2 -sag-longpath -label-video %s -exit &\nwait -n\n",
        who.c_str(), geom.c_str(), iter, who.c_str(), descfile);
      else if(geom == "t3")
      fprintf(script, "sh visualize.sh %s %s %d -color videos/colors-%s.csv \"movement_angle_3=dzy(90)\" ma=1 rv_latex=2 -sag-autoviz -PM 0 -zoom 3/27 -idv \"movement_angle_3=dzx(45)*dxy(90)\" acycle=\"27*sqrt(2)\" -smart 1 -smartlimit 99999 -genlimit 50000 -shot-fhd -shotaa 2 -lw 2 -label-video %s -exit &\nwait -n\n",
        who.c_str(), geom.c_str(), iter, who.c_str(), descfile);
      else if(geom == "h2m")
      fprintf(script, "sh visualize.sh %s %s %d -color videos/colors-%s.csv acycle=30 -smart 1 ma=1 rv_latex=2 -sag-autoviz -shot-fhd -shotaa 2 -lw 2 -label-video %s -exit &\nwait -n\n",
        who.c_str(), geom.c_str(), iter, who.c_str(), descfile);
      else if(geom == "h3m")
      fprintf(script, "sh visualize.sh %s %s %d -color videos/colors-%s.csv \"movement_angle_3=dzy(90)\" ma=1 rv_latex=2 -sag-autoviz -PM 0 -idv \"movement_angle_3=dxz(90)\" acycle=\"1.061275*6\" -PM \"native pers\" -sight3 4 -smartlimit 99999 -genlimit 50000 -shot-fhd -shotaa 2 -lw 2 -label-video %s -exit &\nwait -n\n",
        who.c_str(), geom.c_str(), iter, who.c_str(), descfile);
      else if(geom == "h2r")
      fprintf(script, "sh visualize.sh %s %s %d -color videos/colors-%s.csv \"movement_angle=dzy(90)\" ma=2 rv_latex=2 -sag-autoviz -shot-fhd -shotaa 2 -lw 2 -label-video %s -exit &\nwait -n\n",
        who.c_str(), geom.c_str(), iter, who.c_str(), descfile);
      else fprintf(script, "sh visualize.sh %s %s %d -color videos/colors-%s.csv \"movement_angle_3=dzy(90)\" ma=2 rv_latex=2 -sag-autoviz -shot-fhd -shotaa 2 -lw 2 -label-video %s -exit &\nwait -n\n",
        who.c_str(), geom.c_str(), iter, who.c_str(), descfile);

      count_geom[geom]++;
      fprintf(concat, "file ../full/%s-%s.mp4\n", who.c_str(), geom.c_str());
      }
    }

  for(int a=0; a<6; a++) fprintf(script, "wait\n", a);
  for(auto p: count_geom) fprintf(script, "# %s : %d\n", p.first.c_str(), p.second);

  fclose(script);
  fclose(concat);

  return 0;
  }

// work on: T3 (forget it)
// work on: h2r (improve it)
// work on: twist (improve it)
// work on: Nil (improve it)
