#include <stdio.h>
#include "ghutils.h"

#include <vector>
#include <string>
#include <map>
#include <set>

using ld = double;

struct result {
  ld loglik, mAP, meanrank, success, stretch;
  };

using namespace std;

struct best_result {
  string geometry;
  string file;
  int iteration;
  string mode;
  result res;
  ld radius;
  ld time;
  };

struct cmp_result {
  string mode;
  ld radius;
  ld time;
  int ratio;
  ld val;
  ld val1;
  bool found;
  cmp_result() { found = false; ratio = 0; }
  };

struct cmp_results {
  cmp_result mAP, meanrank, success, stretch;
  };

map<string, best_result> best_results, best_h3, best_h2;

map<string, cmp_results> bh2, bh3;

map<string, int> result_qty;

map<string, int> find_column_id(csvparser& c) {
  map<string, int> column_id;
  for(int i=0; i<c.fields; i++) column_id[c[i]] = i;
  return column_id;
  }

result get_result(csvparser& c, map<string, int>& co) {
  result res;
  res.loglik = -tonum(c[co["loglik"]]);
  res.mAP = tof(c[co["mAP"]]);
  res.meanrank = tof(c[co["meanrank"]]);
  res.success = tof(c[co["success"]]);
  res.stretch = tof(c[co["stretch"]]);
  return res;
  }

void display(map<string, best_result>& table) {
  for(auto& b: table) {
    printf("%-20s & %-10s & %-5s & %7.0f & %8.6f & %6.2f & %6.4f & %6.4f \\ \n",
      b.first.c_str(), b.second.geometry.c_str(), b.second.mode.c_str(), b.second.res.loglik, b.second.res.mAP, b.second.res.meanrank, b.second.res.success, b.second.res.stretch);
    }
  }

int main() {

  set<string> nomes1 = {
    // "CElegans", "Cat2", "Drosophila1", "Human1", "Human6", "Macaque3", "Mouse3"
    "Cat1", "Cat2", "Cat3", "CElegans", "Drosophila1","Drosophila2", "Human1", "Human2", "Human6", "Human7", "Human8", "Macaque1", "Macaque2", "Macaque3", "Macaque4", "Mouse2", "Mouse3", "Rat1", "Rat2", "Rat3",
    "ZebraFinch2", "CElegans", "Drosophila1", "Human1", "Mouse3"
    };

  set<string> nomes;
  for(auto s: nomes1) nomes.insert("connectome/" + s);

  for(string fname: {"other-methods.csv"}) {
    csvparser c(fname, ';');
    c.next();
    auto co = find_column_id(c);

    while(c.next()) {
      auto who = c[co["graph"]];
      if(!nomes.count(who)) continue;
      int dim = tonum(c[co["dim"]]);
      if(tonum(c[co["discrete"]])) continue;
      best_result br;
      if(dim > 3) continue;
      br.geometry = dim == 2 ? "H2" : "H3";
      string mtd = c[co["method"]];
      br.mode = c[co["method"]] + c[co["sid"]];
      if(mtd == "poincare") br.mode = "Poincar\\'e";
      if(mtd == "lorentz") br.mode = "Lorentz";
      if(mtd == "mercatorfull") br.mode = "Mercator (full)";
      if(mtd == "mercatorfast") br.mode = "Mercator (fast)";
      if(mtd == "mercator") br.mode = "Mercator";
      if(mtd == "ltiling") continue;
      if(mtd == "bfkl") br.mode = "BFKL";
      br.res = get_result(c, co);
      if(!br.res.mAP) continue;
      br.radius = tof(c[co["radius"]]);
      br.time = tof(c[co["time"]]);
      result_qty[who]++;

      auto setb = [&] (cmp_result& cr, ld val) {
        cr.mode = br.mode;
        cr.val = val;
        cr.radius = br.radius;
        cr.time = br.time;
        };

      auto improve = [&] (map<string, cmp_results>& table) {
        bool ok = !table.count(who);
        if(ok || table[who].mAP.val < br.res.mAP) setb(table[who].mAP, br.res.mAP);
        if(ok || table[who].success.val < br.res.success) setb(table[who].success, br.res.success);
        if(br.res.meanrank >= 1)
          if(ok || table[who].meanrank.val > br.res.meanrank) setb(table[who].meanrank, br.res.meanrank);
        if(br.res.stretch >= 1)
          if(ok || table[who].stretch.val > br.res.stretch) setb(table[who].stretch, br.res.stretch);
        };

      if(dim == 2) improve(bh2);
      if(dim == 3) improve(bh3);
      }
    }

  for(string fname: {/*"brain-v3.csv", "brain-v4.csv",*/ "brains.csv", "brains-long.csv"}) {
    csvparser c(fname, ';');
    c.next();
    auto co = find_column_id(c);

    while(c.next()) {
      auto who = c[co["who"]];
      // if(who == "Macaque4") continue; /* perfect embedding obtained */
      auto geom = c[co["geom"]];
      best_result br;
      br.geometry = geom;
      br.file = fname;
      br.iteration = tonum(c[co["iteration"]]);
      br.res = get_result(c, co);
      if(fname == "brains.csv") br.mode = "S";
      else if(br.iteration < 30) br.mode = "A";
      else if(br.iteration < 60) br.mode = "B";
      else if(br.iteration < 90) br.mode = "C";

      auto improve = [&] (map<string, best_result>& table) {
        if(!table.count(who) || table[who].res.loglik < br.res.loglik)
          table[who] = br;
        };

      improve(best_results);
      if(geom == "g435" || geom == "g435b2" || geom == "BIG-g435" || geom == "BIG-g435b2") improve(best_h3);

      if(geom == "g711") improve(best_h2);

      // string who1 = who; for(char& ch: who1) ch = tolower(ch);
      string who1 = "connectome/" + who;

      auto cmp = [&] (ld val, cmp_result& cmp, int sign) {
        if(!cmp.found) cmp.val1 = val;
        if(val*sign > cmp.val1*sign) cmp.val1 = val;
        if(val*sign > cmp.val*sign) cmp.ratio++;
        };

      bool only_basic = true;

      if(nomes.count(who1) && (only_basic ? (geom == "g711" && br.mode == "S") : ((geom == "g711" || geom == "tree")))) {
        cmp(br.res.mAP, bh2[who1].mAP, 1);
        cmp(br.res.success, bh2[who1].success, 1);
        cmp(br.res.meanrank, bh2[who1].meanrank, -1);
        cmp(br.res.stretch, bh2[who1].stretch, -1);
        }

      if(nomes.count(who1) && (only_basic ? (geom == "g435b2" && br.mode == "S") : ((geom == "g435b2" || geom == "g435" || geom == "BIG-g435" || geom == "BIG-g435b2")))) {
        cmp(br.res.mAP, bh3[who1].mAP, 1);
        cmp(br.res.success, bh3[who1].success, 1);
        cmp(br.res.meanrank, bh3[who1].meanrank, -1);
        cmp(br.res.stretch, bh3[who1].stretch, -1);
        }

      }
    }

  printf("best results:\n");
  display(best_results);

  /*
  printf("\n\nbest results in H3:\n");
  display(best_h3);

  printf("\n\nbest results in H2:\n");
  display(best_h2);
  */

  auto displaycmp = [&] (string nome, int dim, string measure, cmp_result& c, string fmt) {
    string lfmt = "%-15s & %d & " + fmt + " & %-15s& %4.1f & %4.f & " + fmt + " & %d \\\\ \n";
    auto no = nome;
    no = no.substr(11);
    printf(lfmt.c_str(),
      no.c_str(), dim, /* measure.c_str(), */ c.val, c.mode.c_str(), c.radius, c.time, c.val1, c.ratio);
    };

  printf("\n\n");
  printf("connectome      &dim&  SotA & method         & rad  & time & ours  & better \\\n");

  for(int i=0; i<4; i++) {
    if(i == 0) printf("\nmAP\n");
    if(i == 1) printf("\nMeanRank\n");
    if(i == 2) printf("\nsuccess\n");
    if(i == 3) printf("\nstretch\n");
    for(auto no: nomes) {
      if(i==0) displaycmp(no, 2, "mAP",      bh2[no].mAP, "%5.3f");
      if(i==1) displaycmp(no, 2, "MeanRank", bh2[no].meanrank, "%5.1f");
      if(i==2) displaycmp(no, 2, "success",  bh2[no].success, "%5.3f");
      if(i==3) displaycmp(no, 2, "stretch",  bh2[no].stretch, "%5.3f");

      if(i==0) displaycmp(no, 3, "mAP",      bh3[no].mAP, "%5.3f");
      if(i==1) displaycmp(no, 3, "MeanRank", bh3[no].meanrank, "%5.1f");
      if(i==2) displaycmp(no, 3, "success",  bh3[no].success, "%5.3f");
      if(i==3) displaycmp(no, 3, "stretch",  bh3[no].stretch, "%5.3f");
      }
    }

  for(auto re: result_qty) printf("%3d %s\n", re.second, re.first.c_str());
  // g435b2: radius = 3.65036, 600 seconds on mouse3
  // g711: radius = 7.60173, 230 seconds on mouse3

  return 0;
  }
